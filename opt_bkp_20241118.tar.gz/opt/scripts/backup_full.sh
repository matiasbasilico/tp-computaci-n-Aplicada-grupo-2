#!/bin/bash

DESTINATION=$2
SOURCE=$1
DATE=$(date +%Y%m%d)

if [[ "$1" == "-h" ]]; then
  echo "Uso: $0 [directorio_origen] [directorio_destino]"
  echo "  directorio_origen   Directorio a respaldar (por ejemplo: /etc)"
  echo "  directorio_destino  Directorio donde se guardará el backup (por ejemplo: /backup_dir)"
  exit 0
fi

if [[ -z "$SOURCE" || -z "$DESTINATION" ]]; then
  echo "Error: Debes proporcionar los argumentos de origen y destino."
  echo "Usa $0 -h para más detalles."
  exit 1
fi

if [[ ! -d "$SOURCE" ]]; then
  echo "Error: El directorio de origen '$SOURCE' no existe o no está montado."
  exit 1
fi

if [[ ! -d "$DESTINATION" ]]; then
  echo "Error: El directorio de destino '$DESTINATION' no existe o no está montado."
  exit 1
fi


BASENAME=$(basename "$SOURCE")
BACKUP_FILE="${DESTINATION}/${BASENAME}_bkp_${DATE}.tar.gz"

tar -czf "$BACKUP_FILE" "$SOURCE"
if [[ $? -eq 0 ]]; then
  echo "Backup exitoso: $BACKUP_FILE"
else
  echo "Error al realizar el backup."
  exit 1
fi

exit 0
